#pragma once

#ifdef __cplusplus
#include "src/Protocol.hpp"
#else
#error Requires a C++ compiler, please change file extension to .cc or .cpp
#endif